from django import forms

from .models import BookDetailsModel

class addBookField(forms.ModelForm):
    class Meta:
        model = BookDetailsModel
        fields = ['name' , 'genre' , 'price']
        
        widgets = {
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'genre':forms.Select(attrs={'class':'form-control'}),
            'price':forms.TextInput(attrs={'class':'form-control'}),
        }
        


