from django.contrib import admin
from .models import BookDetailsModel

# Register your models here.
admin.site.register(BookDetailsModel)