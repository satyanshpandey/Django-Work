from django.db import models

# Create your models here.
class BookDetailsModel(models.Model):
    
    GENRE_CHOICES = [
        ('Fiction', 'Fiction'),
        ('Non-Fiction', 'Non-Fiction'),
        ('Fantasy', 'Fantasy'),
        ('Mystery/Thriller', 'Mystery/Thriller'),
        ('Science Fiction', 'Science Fiction'),
        ('Romance', 'Romance'),
        ('Historical Fiction', 'Historical Fiction'),
        ('Horror', 'Horror'),
        ('Biography/Autobiography', 'Biography/Autobiography'),
        ('Self-Help', 'Self-Help'),
        ('Classic Literature', 'Classic Literature'),
        ('Young Adult', 'Young Adult'),
        ('Adventure', 'Adventure'),
        ('Dystopian', 'Dystopian'),
        ('Poetry', 'Poetry'),
    ]
    
    name = models.CharField(max_length=111)
    genre = models.CharField(max_length=111 ,choices=GENRE_CHOICES,)
    price = models.CharField(max_length=6)
    
    
    def __str__(self):
        return self.name