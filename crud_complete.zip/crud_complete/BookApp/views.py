from django.shortcuts import render , HttpResponseRedirect
from .forms import addBookField
from .models import BookDetailsModel
# Create your views here.
def show__Books(request):
    if request.method == 'POST':
        fm = addBookField(request.POST)
        if fm.is_valid():
            fm.save()
            fm = addBookField()
    else:
        fm = addBookField()
    allBooksDetails = BookDetailsModel.objects.all()
    return render(request , 'bookDisplay.html', {'form':fm , 'allDetails':allBooksDetails})

def delete_data(request , id):
    if request.method == 'POST':
        pi = BookDetailsModel.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')
    
def updateData(request , id):
    if  request.method == 'POST':
        pi = BookDetailsModel.objects.get(pk=id)
        fm = addBookField(request.POST , instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = BookDetailsModel.objects.get(pk=id)
        fm = addBookField(instance=pi)
    return render(request , 'updaate.html' , {'form':fm})
    
    # return render(request , 'updaate.html' , {'id':id})