from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import TODO
from .forms import TODOForms

from django.contrib.auth.decorators import login_required

# Create your views here.
from django.contrib.auth import authenticate , login as login_user , logout
from django.contrib.auth.forms import (UserCreationForm,AuthenticationForm,AdminPasswordChangeForm, 
                                       PasswordChangeForm, PasswordResetForm, ReadOnlyPasswordHashField,
                                       ReadOnlyPasswordHashWidget ,SetPasswordForm , UserChangeForm,
                                       UsernameField)

@login_required(login_url='login')
def home(request):
    if request.user.is_authenticated:
        user = request.user
        form = TODOForms()
        TODO_data = TODO.objects.filter(user = user).order_by('priority')
        print("This is the todo data coming from models: ",TODO_data)
        return render(request , 'index.html' , context = {'form':form , 'todos':TODO_data})
    

def login(request):
    if request.method == 'GET':
        form = AuthenticationForm()
        context = {
            'form':form,
        }
        return render(request , 'login.html' , context=context)
    else:
        form = AuthenticationForm(data = request.POST)
        print(form.is_valid())
        # print(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username,password=password) # ye hmme ek object return karega...
            print("user................>>>>>>>>>>>>>>>>>>>>......",user)
            if user is not None:
                login_user(request , user)
                return redirect('home')
        else:
            context = {
                'form':form,
            }
            return render(request , 'login.html' , context=context)
        
        
        
        
        
        
        
        
        
        
        
def signup(request):
    if request.method == 'GET':
        fm = UserCreationForm()
        context = {
            'form':fm,
        }
        return render(request , 'signup.html',context=context)
    else:
        print("request.POST form details: ",request.POST)
        fm = UserCreationForm(request.POST) # ye ek form create ho rha hai usercreaation ki help se aaur usme request.post se data bhi aa rha hai...
        
        context = {
            'form':fm,
        } 
        if fm.is_valid():
            user = fm.save()
            print("This is user--------------------> ",user)
            if user is not None:
              return redirect('login')
        else:
            return render(request ,  'signup.html' , context=context)
            # return HttpResponse("Form is invalid")






@login_required(login_url='login')
def addTodo(request):
    if request.user.is_authenticated:
        user = request.user
        print("This is authenticated user.....",user)
        form = TODOForms(request.POST)
        print("This is formmmmmmmmmmmm dataaaaaaaaa:",form)
        if form.is_valid():
            print("This is form data cleaned data--------------> ",form.cleaned_data)
            todo = form.save(commit=False)
            todo.user = user
            todo.save()
            print("Todo ------********************* this is todo saved data from form todo: ---> ",type(todo),"   ",todo.priority)
            return redirect('home')
        else:
            return render(request , 'index.html' , context = {'form':form})
    
    
    

def all_Form_Display(request):
    
      # Creating a test user for the forms that require a user instance
    test_user = User.objects.first() 
    # or User(username="TestUser")
    
    
    fm1 = UserCreationForm()
    fm2 = AuthenticationForm()
    fm3 = AdminPasswordChangeForm(user=test_user)
    fm4 = PasswordChangeForm(user=test_user)
    fm5 = PasswordResetForm()
    # fm6 = ReadOnlyPasswordHashField()
    # fm7 = ReadOnlyPasswordHashWidget()
    fm8 = SetPasswordForm(user=test_user)
    fm9 = UserChangeForm()
    # fm10 = UsernameField()
    
    context = {
        'fm1':fm1,
        'fm2':fm2,
        'fm3':fm3,
        'fm4':fm4,
        'fm5':fm5,
        # 'fm6':fm6,
        # 'fm7':fm7,
        'fm8':fm8 ,
        'fm9':fm9 ,
        # 'fm10':fm10      
    }
    return render(request , 'allFormDisplay.html', context=context)



def signout(request):
    logout(request)
    return redirect('login')

def delete_todo(request , id):
    print("this is the delete todo id: ",id)
    TODO.objects.get(pk = id).delete()
    return redirect('home')

def change_todo(request , id , status):
    # print("this is the delete todo id: ",id)
    todo = TODO.objects.get(pk = id)
    # print("tttttttttttttttttt",todo)
    todo.status = status 
    # print("aaaaaaaaaaaaaaaaa",todo.status)
    todo.save()
    return redirect('home')

def aboutme(request):
    return render(request , 'aboutme.html')