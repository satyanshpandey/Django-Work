
from django.urls import path
from .views import home , login ,signup , all_Form_Display  , addTodo , signout , delete_todo , change_todo, aboutme
from django.shortcuts import HttpResponse

    
urlpatterns = [
    path("", home , name='home'),
    path('login' , login , name='login'),
    path('signup' , signup),
    path('all' , all_Form_Display),
    path('add-todo' , addTodo , name="addTodo"),
    path('logout' , signout ),
    path('delete-todo/<int:id>' , delete_todo),
    path('change-status/<int:id>/<str:status>' , change_todo),
    path('aboutme' , aboutme)
]
