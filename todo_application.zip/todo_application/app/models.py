from django.db import models
from django.contrib.auth.models import User
# Create your models here. 
# class User(models.Model):
#     name = models.CharField(max_length=111)
#     lname = models.CharField(max_length=111)
    
    
# class TODO(models.Model):
#     status__choices = [
#         ('C','COMPLETED'),
#         ('P','PENDING'),
#     ]
#     priorityChoices = [
#         ('1','One'),
#         ('2' , 'Two'),
#         ('3', 'Three'),
#         ('4' , 'Four'),
#         ('5' , 'Five'),
#         ('6','Six'),
#         ('7' , 'Seven'),
#         ('8' , 'Eight'),
#         ('9' , 'Nine'),
#         ('10', 'Ten'),
#     ]
#     title = models.CharField(max_length=111)
#     status = models.CharField(max_length=111 , choices=status__choices , default="P")
#     date = models.DateField(auto_now_add=True) # iska matlab ki iskaa data automatically save ho jayega , hamme kuch karne ki jarurat nhi h 
#     user = models.ForeignKey(User , on_delete=models.CASCADE) 
#     priority = models.CharField(max_length=111 , choices=priorityChoices)
    
    
#     def __str__(self):
#         return self.title




class TODO(models.Model):
    status__choices = [
        ('C', 'COMPLETED'),
        ('P', 'PENDING'),
    ]
    priorityChoices = [
        (1, 'One'),
        (2, 'Two'),
        (3, 'Three'),
        (4, 'Four'),
        (5, 'Five'),
        (6, 'Six'),
        (7, 'Seven'),
        (8, 'Eight'),
        (9, 'Nine'),
        (10, 'Ten'),
    ]
    title = models.CharField(max_length=111)
    status = models.CharField(max_length=111, choices=status__choices, default="P")
    date = models.DateField(auto_now_add=True)  # Auto-save the date
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    priority = models.IntegerField(choices=priorityChoices)  # Changed to IntegerField

    def __str__(self):
        return self.title
